title: Java异常
date: '2019-11-24 17:20:15'
updated: '2019-11-24 17:20:15'
tags: [Error, Exception]
permalink: /articles/2019/11/24/1574587215679.html
---
####	1、异常处理机制主要回答了三个问题
*	what：异常类型回答了什么被抛出
*	where：异常堆栈回答了在哪里抛出
*	why：异常信息回答了什么被抛出
####	2、Error和Exception的区别
#####	2.1、从概念角度解析Java异常处理机制
*	Error：程序无法处理的系统错误，编译器不做检查
*	Exception：程序可以处理的异常，捕获可能恢复
*	总结：前者是程序无法处理的错误，后者是可以处理的异常
#####	2.2、从责任的角度看
*	Error属于JVM需要负担的责任
*	RuntimeException是程序应该负担的责任
*	Checked Exception可检查异常是Java编译器应该负担的责任
####	3、常见的Error以及Exception
#####	3.1、RuntimeException
*	NullPointExcepiton	- 空指引用异常
*	ClassCastException - 类型转换异常
*	IllegalArgumentException - 传递非法参数异常
*	IndexOutOfBoundsException - 下标越界异常
*	NumberFormatException - 数字格式异常
#####	3.2、非RunTimeException
*	ClassNotDFoundExcepiton - 找不到指定class的异常
*	IOException - IO 操作异常
#####	3.3、Error
*	NoClassDefFoundError - 找不到class定义的异常
*	StackOverflowError - 深递归导致栈被耗尽而抛出的异常
*	OutOfMemoryError - 内存溢出异常
 
##### 异常Demo
```
//常见的Exception
    //继承于 RuntimeException
    //1、NullPointerException    空指针异常
    @Test
    public  void testNullPointerException(){
        String str = null;
        str.length();
    }
    //2、ClassCastExcepiton  类型强制转换异常
    @Test
    public void  testClassCastException(){
        Object obj = "str";
        String str = (String)obj;
        Integer i = (Integer)obj;
    }
    //3、IllegalArgumentException 传递非法参数异常
    @Test
    public void testIllegalArgumentException(){
        setPercentage(101);
    }
    void setPercentage(int pct){
        if (pct <0 || pct > 100) {
            throw new IllegalArgumentException("bad percent");
        }
    }

    //4、IndexOutOfBoundsException 下标越界异常
    @Test
    public void testIndexOutOfBoundsException(){
        List list = new ArrayList<>(10);
        System.err.println(list.get(10));
    }

    //5、NumberFormatException  数字格式转换异常
    @Test
    public void testNumberFormatException(){
        Integer.valueOf("dsfd");
    }
    
    //6、ClassNotFoundException 找不到指定class异常
    @Test
    public void testClassNotFoundException(){
        try{
            Class.forName("com.hugo.Test");
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        }
    }
    
    //7、IOException
    @Test
    public void testIOException(){
        BufferedReader reader = null;
        File file = null;
        try {
            file = new File("C:\\Users\\edhugo\\Desktop\\config.properties");
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            while ((tempString = reader.readLine())!=null){
                System.err.println(tempString);
                line++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    //8、StackOverflowError 深度递归导致栈被耗尽而抛出的异常
    @Test
    public void testRecursive(){
        testRecursive();
    }
    
    //9、OutOfMemoryError 内存溢出异常
    @Test
    public void testOutOfMemoryError(){
        List<byte[]> list = new ArrayList<>();
        int i = 0;
        while (true){
            list.add(new byte[5*1024*1024]);
            System.err.println("分配次数"+(++i));
        }
    }
```

####	4、NoClassDefFoundError的成因（了解）
*	类依赖的class或者jar不存在
*	类文件存在，但是存在不同的域中
*	大小写问题，javac编译的时候是无视大小写的，很有可能编译出来的class文件就与想要的不一样
####	5、Java的异常处理机制
*	抛出异常：创建异常对象，交由运行时的系统处理
*	捕获异常：寻找合适的异常处理器处理异常，否则终止运行
```
private void writWithARM() throws IOException{
	try(DataOutputStream out = new DataOutputStream(new FileOutputStream("data"))){
		out.writeInt(666);
		out.writeUTF("Hello");
	}
}
```
####	6、Java异常的处理原则
*	具体明确：抛出的异常应能够通过异常类名和message准确说明异常的类型和产生异常的原因
*	提早抛出：应尽可能早的发现并抛出异常，便于精确定位问题
*	延迟捕获：异常的捕获和处理应尽可能延迟，让掌握更多信息的作用域来处理异常
####	7、高效主流的异常处理框架
在用户看来，应用系统发生的所有异常都是应用系统内部的异常
*	设计一个通用的继承自RuntimeException的异常来统一处理
*	其余异常统一转译为上述异常AppException
*	在catch之后，抛出上述异常的子类，并提供足以定位的信息
*	由前端接收AppException做统一处理
![clipboard.png](https://img.hacpai.com/file/2019/11/clipboard-0b1bf496.png)
####	8、Java异常处理消耗性能的地方
*	try-catch块影响JVM的优化
*	异常对象实例需要保存栈快照等信息，开销较大

