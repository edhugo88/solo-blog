title: docker+Elasticsearch安装
date: '2019-11-21 18:29:28'
updated: '2019-11-22 15:33:48'
tags: [docker, es]
permalink: /articles/2019/11/21/1574332168234.html
---
## Elasticsearch安装

* 下载elasticsearch6.4.0的docker镜像：

```
docker pull elasticsearch:6.4.0
```

* 修改虚拟内存区域大小，否则会因为过小而无法启动:

```
sysctl -w vm.max_map_count=262144
```

* 使用docker命令启动：

```
  docker run -p 9200:9200 -p 9300:9300 --name elasticsearch \
  -e "discovery.type=single-node" \
  -e "cluster.name=elasticsearch" \
  -v /mydata/elasticsearch/plugins:/usr/share/elasticsearch/plugins \
  -v /mydata/elasticsearch/data:/usr/share/elasticsearch/data \
  -d elasticsearch:6.4.0
```

* 启动时会发现/usr/share/elasticsearch/data目录没有访问权限，只需要修改/mydata/elasticsearch/data目录的权限，再重新启动。

```
chmod 777 /mydata/elasticsearch/data/
```

* 安装中文分词器IKAnalyzer，并重新启动：

```
docker exec -it elasticsearch /bin/bash
#此命令需要在容器中运行
elasticsearch-plugin install https://github.com/medcl/elasticsearch-analysis-ik/releases/download/v6.4.0/elasticsearch-analysis-ik-6.4.0.zip
docker restart elasticsearch
```

* 开启防火墙：

```
firewall-cmd --zone=public --add-port=9200/tcp --permanent
firewall-cmd --reload
```

* 访问会返回版本信息：[http://192.168.3.101:9200/](http://192.168.3.101:9200/)
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca5829efd81?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    
## kibana安装

* 下载kibana6.4.0的docker镜像：

```
docker pull kibana:6.4.0
```

* 使用docker命令启动：

```
  docker run --name kibana -p 5601:5601 \
  --link elasticsearch:es \
  -e "elasticsearch.hosts=http://es:9200" \
  -d kibana:6.4.0
```

* 开启防火墙：

```
firewall-cmd --zone=public --add-port=5601/tcp --permanent
firewall-cmd --reload
```

* 访问地址进行测试：[http://192.168.3.101:5601](http://192.168.3.101:5601)
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca581830ca0?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
   


作者：MacroZheng  
链接：https://juejin.im/post/5d1802ab6fb9a07f0a2df5ae  
来源：掘金  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
