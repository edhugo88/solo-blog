title: docker+nginx安装
date: '2019-11-21 18:07:31'
updated: '2019-11-21 18:08:23'
tags: [docker, nginx]
permalink: /articles/2019/11/21/1574330851807.html
---
## Nginx安装

### 下载nginx1.10的docker镜像：

```
docker pull nginx:1.10
```

### 从容器中拷贝nginx配置

* 先运行一次容器（为了拷贝配置文件）：

```
  docker run -p 80:80 --name nginx \
  -v /mydata/nginx/html:/usr/share/nginx/html \
  -v /mydata/nginx/logs:/var/log/nginx  \
  -d nginx:1.10
```

* 将容器内的配置文件拷贝到指定目录：

```
docker container cp nginx:/etc/nginx /mydata/nginx/
```

* 修改文件名称：

```
mv nginx conf
```

* 终止并删除容器：

```
docker stop nginx
docker rm nginx
```

### 使用docker命令启动：

```
docker run -p 80:80 --name nginx \
-v /mydata/nginx/html:/usr/share/nginx/html \
-v /mydata/nginx/logs:/var/log/nginx  \
-v /mydata/nginx/conf:/etc/nginx \
-d nginx:1.10
```
  
作者：MacroZheng  
链接：https://juejin.im/post/5d1802ab6fb9a07f0a2df5ae  
来源：掘金  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
