title: SpringBoot面试题(一)
date: '2019-11-20 12:18:06'
updated: '2019-11-20 14:59:13'
tags: [spring, SpringBoot]
permalink: /articles/2019/11/20/1574223486112.html
---
#### 1、什么是springboot
*	用来简化spring应用的初始搭建以及开发过程，使用特定方式来进行配置（properties或yml文件）
*	创建独立的spring应用程序，main方法运行
*	内嵌tomcat无需部署war文件
* 	简化maven配置
* 	自动配置spring添加对应功能starter自动化配置（[# 如何实现自己的Spring Boot Starter](https://https://blog.csdn.net/feeltouch/article/details/89443306)）
* 	**总结:** spring boot来简化spring应用开发，约定大于配置，去繁从简，just run就能创建一个独立的，产品级别的应用
#### 2、Spring Boot有哪些优点？
*	快速创建独立运行的spring项目与主流框架集成
*	使用嵌入式servlet容器，应用无需打成war包
*	staters自动依赖与版本控制
*	大量自动配置，简化开发，也可以修改默认值
*	准生产环境的运行应用监控([#spring监控](https://codecentric.github.io/spring-boot-admin/1.5.7/))

####  3、如何重新加载Spring Boot上的更改，而无需重新启动服务器([#springboot热部署](https://www.cnblogs.com/liu2-/p/9118393.html))？
*	spring为开发者提供了一个名为spring-boot-devtools的模块来使Spring Boot应用支持热部署，提高开发者的开发效率，无需手动重启Spring Boot应用。
*     pom.xml
```
<dependency> 
	<groupId>org.springframework.boot</groupId> 
	<artifactId>spring-boot-devtools</artifactId> 
	<optional>true</optional> 
</dependency>
```
*   application.properties
```
#热部署生效
 spring.devtools.restart.enabled: true 
#设置重启的目录 
spring.devtools.restart.additional-paths: src/main/java 
#classpath目录下的WEB-INF文件夹内容修改不重启 spring.devtools.restart.exclude: WEB-INF/**
```
####	4、Spring Boot中的监视器是什么？
*	Spring boot actuator是spring启动框架中的重要功能之一。Spring boot监视器可帮助您访问生产环境中正在运行的应用程序的当前状态。   
*	有几个指标必须在生产环境中进行检查和监控。即使一些外部应用程序可能正在使用这些服务来向相关人员触发警报消息。监视器模块公开了一组可直接作为HTTP URL访问的REST端点来检查状态。

####	5、什么是YAML？
*	YAML是一种人类可读的数据序列化语言。它通常用于配置文件。   
*	与属性文件相比，如果我们想要在配置文件中添加复杂的属性，YAML文件就更加结构化，而且更少混淆。可以看出YAML具有分层配置数据。
#####	6、如何集成Spring Boot和ActiveMQ？   
*	对于集成Spring Boot和ActiveMQ，我们使用spring-boot-starter-activemq依赖关系。 它只需要很少的配置，并且不需要样板代码。
例如：
```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-activemq</artifactId>
    <version>2.2.1.RELEASE</version>
</dependency>
```
####	7、springboot常用的starter有哪些   
*	spring-boot-starter-web 嵌入tomcat和web开发需要servlet与jsp支持   
*	spring-boot-starter-data-jpa 数据库支持   
*	spring-boot-starter-data-redis redis数据库支持   
*	spring-boot-starter-data-solr solr支持   
*	mybatis-spring-boot-starter 第三方的mybatis集成starter

####	8、springboot自动配置的原理   
>	在spring程序main方法中 添加@SpringBootApplication或者@EnableAutoConfiguration 会自动去maven中读取每个starter中的spring.factories文件 该文件里配置了所有需要被创建spring容器中的bean
####	9、springboot读取配置文件的方式   
>	springboot默认读取配置文件为application.properties或者是application.yml

####	10、springboot集成mybatis的过程   
>	添加mybatis的starter maven依赖 
*	pom.xml
```
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>1.2.0</version>
</dependency>
```
*	application.properties 配置数据源信息
```
mybatis.mapperLocations=classpath:mapping/*.xml

```
*    在mybatis的接口中 添加@Mapper注解   
```
import org.mybatis.spring.annotation.Mapper;
@Mapper()//扫描dao文件

```
 ####	11、Spring Boot、Spring MVC 和 Spring 有什么区别？

*	 **SpringFrame**

> SpringFramework 最重要的特征是依赖注入。所有 SpringModules 不是依赖注入就是 IOC 控制反转。

当我们恰当的使用 DI 或者是 IOC 的时候，我们可以开发松耦合应用。松耦合应用的单元测试可以很容易的进行。

*	**SpringMVC**

> Spring MVC 提供了一种分离式的方法来开发 Web 应用。通过运用像 DispatcherServelet，MoudlAndView 和 ViewResolver 等一些简单的概念，开发 Web 应用将会变的非常简单。

*	 **SpringBoot**

Spring 和 SpringMVC 的问题在于需要配置大量的参数。

```
<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver"><property name="prefix">        
		<value>/WEB-INF/views/</value>    
	</property>    
	<property name="suffix">        
		<value>.jsp</value>    
	</property>  </bean>   
	<mvc:resources mapping="/webjars/**" location="/webjars/"/>
</bean>
```

Spring Boot 通过一个自动配置和启动的项来目解决这个问题。为了更快的构建产品就绪应用程序，Spring Boot 提供了一些非功能性特征。


 

