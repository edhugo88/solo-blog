title: SpringBoot面试题(二)
date: '2019-11-20 15:16:18'
updated: '2019-11-20 15:17:41'
tags: [Spring, SpringBoot]
permalink: /articles/2019/11/20/1574234178507.html
---
####	我们如何连接一个像 MYSQL 或者 orcale 一样的外部数据库？

让我们以 MySQL 为例来思考这个问题：

#####	第一步 - 把 mysql 连接器的依赖项添加至 pom.xml

```
<dependency>    
	<groupId>mysql</groupId>    
	<artifactId>mysql-connector-java</artifactId>
</dependency>
```

#####	第二步 - 从 pom.xml 中移除 H2 的依赖项

或者至少把它作为测试的范围。

```
<!--
<dependency>    
	<groupId>com.h2database</groupId>    
	<artifactId>h2</artifactId>
	<scope>test</scope>
</dependency>-->   
```

#####	第三步 - 安装你的 MySQL 数据库

#####	第四步 - 配置你的 MySQL 数据库连接

配置 application.properties

```
spring.datasource.url=jdbc:mysql://localhost:3306/todo_example
spring.datasource.username=todouser
spring.datasource.password=YOUR_PASSWORD   
```

#####	第五步 - 重新启动，你就准备好了！

就是这么简单！

未完待续.....
