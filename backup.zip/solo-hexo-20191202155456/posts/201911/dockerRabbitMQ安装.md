title: docker+RabbitMQ安装
date: '2019-11-21 18:28:01'
updated: '2019-11-21 18:28:01'
tags: [docker, rabbitMq]
permalink: /articles/2019/11/21/1574332081643.html
---
## RabbitMQ安装

* 下载rabbitmq3.7.15的docker镜像：

```
docker pull rabbitmq:3.7.15
```

* 使用docker命令启动：

```
  docker run -d --name rabbitmq \
  --publish 5671:5671 --publish 5672:5672 --publish 4369:4369 \
  --publish 25672:25672 --publish 15671:15671 --publish 15672:15672 \
  rabbitmq:3.7.15
```

* 进入容器并开启管理功能：

```
docker exec -it rabbitmq /bin/bash
rabbitmq-plugins enable rabbitmq_management
```

![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca54e36c1dc?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)

* 开启防火墙：

```
firewall-cmd --zone=public --add-port=15672/tcp --permanent
firewall-cmd --reload
```

* 访问地址查看是否安装成功：[http://192.168.3.101:15672/](http://192.168.3.101:15672/)
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca54ee4872f?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    
* 输入账号密码并登录：guest guest
* 创建帐号并设置其角色为管理员：mall mall
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca54f15bf8b?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    
* 创建一个新的虚拟host为：/mall
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca55050fc7d?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    
* 点击mall用户进入用户配置页面
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca550fc2dc0?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    
* 给mall用户配置该虚拟host的权限
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca57ebeddbe?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    

  
作者：MacroZheng  
链接：https://juejin.im/post/5d1802ab6fb9a07f0a2df5ae  
来源：掘金  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
