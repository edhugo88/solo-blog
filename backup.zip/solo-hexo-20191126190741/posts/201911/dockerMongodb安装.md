title: docker+Mongodb安装
date: '2019-11-21 18:32:05'
updated: '2019-11-21 18:32:20'
tags: [docker, Mongodb]
permalink: /articles/2019/11/21/1574332324871.html
---
## Mongodb安装

* 下载mongo3.2的docker镜像：

```
docker pull mongo:3.2
```

* 使用docker命令启动：

```
  docker run -p 27017:27017 --name mongo \
  -v /mydata/mongo/db:/data/db \
  -d mongo:3.2
```

## Docker全部环境安装完成

* 所有下载镜像文件：
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba7b1950cbb629?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    
* 所有运行在容器里面的应用：
    
    ![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba7b195172117b?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
    

  
作者：MacroZheng  
链接：https://juejin.im/post/5d1802ab6fb9a07f0a2df5ae  
来源：掘金  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
