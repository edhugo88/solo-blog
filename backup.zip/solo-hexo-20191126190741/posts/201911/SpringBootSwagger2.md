title: SpringBoot+Swagger2
date: '2019-11-21 12:09:40'
updated: '2019-11-21 12:27:55'
tags: [swagger]
permalink: /articles/2019/11/21/1574309380546.html
---
官网：[https://swagger.io/](https://links.jianshu.com/go?to=https%3A%2F%2Fswagger.io%2F)
原文地址 : https://www.jianshu.com/p/a66cf3acd29a
#### Swagger2应用组成

#####	1、 pom.xml 配置Maven依赖

```xml
	<dependency>
		<groupId>io.springfox</groupId>
		<artifactId>springfox-swagger2</artifactId>
		<version>2.9.2</version>
	</dependency>
	
	<!--springfox swagger ui-->
	<dependency>
		<groupId>io.springfox</groupId>
		<artifactId>springfox-swagger-ui</artifactId>
		<version>2.9.2</version>
	</dependency>
	
	<!--swagger ui layer-->
	<dependency>
		<groupId>com.github.caspar-chen</groupId>
		<artifactId>swagger-ui-layer</artifactId>
		<version>1.1.3</version>
	</dependency>
	
	<!--swagger bootstrap ui-->
	<dependency>
		<groupId>com.github.xiaoymin</groupId>
		<artifactId>swagger-bootstrap-ui</artifactId>
		<version>1.8.7</version>
	</dependency>
```

#####	2、Swagger配置类

```java
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Value(value = "${swagger.enable}")
    private Boolean swaggerEnable;

    @Bean
    public Docket buildDocket() {
        return new Docket(DocumentationType.SWAGGER_2)
                .pathMapping("")
                .enable(swaggerEnable)
                .apiInfo(buildApiInfo())
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo buildApiInfo() {
        Contact contact = new Contact("团队名", "www.my.com", "my@my.com");
        return new ApiInfoBuilder()
                .title("文档标题")
                .description("文档描述")
                .contact(contact)//联系方式
                .version("1.0")//版本
                .build();
    }

}
```

#####	3、application.properites配置

```properites
swagger.enable=true//根据环境配置true/false
```


#####	4、在Controller中使用Swagger注解

```java

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Api(tags="接口所在的类")
@RequestMapping ("/my")
public class MyController {

    @RequestMapping(value="/list", method=RequestMethod.POST)
    @ApiOperation(value = "接口名", notes = "接口描述", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "length",value = "参数1", required = true, paramType = "path"),
            @ApiImplicitParam(name = "size",value = "参数2", required = true, paramType = "query"),
            @ApiImplicitParam(name = "page",value = "参数3", required = true, paramType = "header"),
            @ApiImplicitParam(name = "total",value = "参数4", required = true, paramType = "form"),
            @ApiImplicitParam(name = "start",value = "参数5",dataType = "string", paramType = "body")
    })
    public String register(){
        return "has permission";
    }
}

```

5、访问接口文档：localhost:8080/swagger-ui.html  
6、swagger-ui.html 中导出的API文件可以在 Swagger Editor（[http://editor.swagger.io/](https://links.jianshu.com/go?to=http%3A%2F%2Feditor.swagger.io%2F)) 中打开
7、参考：https://github.com/edhugo88/spring-boot-demo/tree/master/node-swagger
  
 
