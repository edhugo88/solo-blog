title: Docker+Redis安装
date: '2019-11-21 18:06:09'
updated: '2019-11-21 18:06:09'
tags: [docker, redis]
permalink: /articles/2019/11/21/1574330769374.html
---
## Redis安装

* 下载redis3.2的docker镜像：

```
docker pull redis:3.2
```

* 使用docker命令启动：

```
  docker run -p 6379:6379 --name redis \
  -v /mydata/redis/data:/data \
  -d redis:3.2 redis-server --appendonly yes
```

* 进入redis容器使用redis-cli命令进行连接：

```
docker exec -it redis redis-cli
```

![展示图片](https://user-gold-cdn.xitu.io/2019/6/30/16ba5ca54ddf44f3?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)


作者：MacroZheng  
链接：https://juejin.im/post/5d1802ab6fb9a07f0a2df5ae  
来源：掘金  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
