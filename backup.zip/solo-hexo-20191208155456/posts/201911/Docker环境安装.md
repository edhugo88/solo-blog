title: Docker环境安装
date: '2019-11-21 18:00:35'
updated: '2019-11-21 18:00:56'
tags: [docker]
permalink: /articles/2019/11/21/1574330435460.html
---
* 安装yum-utils：

```
yum install -y yum-utils device-mapper-persistent-data lvm2
```

* 为yum源添加docker仓库位置：

```
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
```

* 安装docker：

```
yum install docker-ce
```

* 启动docker：

```
systemctl start docker
```

  
作者：MacroZheng  
链接：https://juejin.im/post/5d1802ab6fb9a07f0a2df5ae  
来源：掘金  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
