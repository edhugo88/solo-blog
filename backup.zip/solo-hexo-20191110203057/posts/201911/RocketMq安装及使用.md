title: RocketMq安装及使用
date: '2019-11-08 12:12:10'
updated: '2019-11-08 12:16:07'
tags: [rocketmq]
permalink: /articles/2019/11/08/1573186330802.html
---
## 1.	前置条件 
1. 64bit OS, Linux/Unix/Mac is recommended;
2. 64bit JDK 1.8+; 
3. Maven 3.2.x; 
4. Git;
5. 4g+ free disk for Broker server 
## 	2.	下载安装 

``` 
#选择安装目录 
cd /usr/local 
#下载
wget http://mirrors.tuna.tsinghua.edu.cn/apache/rocketmq/4.4.0/rocketmq-all-4.4.0-source-release.zip 
#解压 
unzip rocketmq-all-4.4.0-source-release.zip 
#切换目录
cd rocketmq-all-4.4.0/
#编译 
mvn -Prelease-all -DskipTests clean install -U 
#切换目录
cd distribution/target/apache-rocketmq 
``` 
## 	3.	修改配置
``` 
vim conf/broker.conf 
``` 
![图片描述](//img.mukewang.com/5db84cbc00010e7113080702.png) 
``` 
vim bin/mqbroker.xml 
``` 
![图片描述](//img.mukewang.com/5db84d610001e27313080702.png) 
``` 
vim bin/runbroker.sh 
``` 
![图片描述](//img.mukewang.com/5db84df60001a0e213080702.png) 
## 	4.	Start Name Server
``` 
nohup sh bin/mqnamesrv & -n 公网ip:9876 
#查看启动日志 
tail -f ~/logs/rocketmqlogs/namesrv.log 
```
## 	5.	Start Broker
``` 
nohup bin/mqbroker -n 公网IP:9876 -c conf/broker.conf autoCreateTopicEnable=true & 
#查看启动日志 
tail -f ~/logs/rocketmqlogs/namesrv.log 
```
## 	6.	Add Topic
```
bin/mqadmin updateTopic -n localhost:9876 -t myTopic -c DefaultCluster
```
## 	7.	Send & Receive Messages
```
 export NAMESRV_ADDR=localhost:9876
 sh bin/tools.sh org.apache.rocketmq.example.quickstart.Producer

 sh bin/tools.sh org.apache.rocketmq.example.quickstart.Consumer
```

## 	8.	Shutdown Servers

```
sh bin/mqshutdown broker
sh bin/mqshutdown namesrv
```
## 	9.	windows 环境启动

配置环境变量：ROCKETMQ_HOME

![微信图片20191108121517.png](https://img.hacpai.com/file/2019/11/微信图片20191108121517-ba37ccd3.png)

```
bin/mqnamesrv.cmd &
bin/mqbroker.cmd -n localhost:9876 -c conf/broker.conf autoCreateTopicEnable=true &
bin/mqadmin.cmd updateTopic -n localhost:9876 -t stock -c DefaultCluster
```
## 	参考文档	
- [Apache RocketMQ](https://rocketmq.apache.org/docs/quick-start/)</br>
 

