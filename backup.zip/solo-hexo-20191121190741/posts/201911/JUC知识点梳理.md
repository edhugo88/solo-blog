title: JUC知识点梳理
date: '2019-11-12 23:10:46'
updated: '2019-11-12 23:31:46'
tags: [java, juc]
permalink: /articles/2019/11/12/1573571446386.html
---
### JUC知识点梳理
#### java.util.concurrent: 提供了并发编程的解决方案
* **CAS**是j**ava.util.concurrent.atomic**包的基础
* **AQS**是**java.util.concurrent.locks**包以及一些常用类比如**Semophore**,**ReentrantLock**等类的基础
### JUC包的分类
*	线程执行器executor
*	锁locks
*	原子变量类atomic
* 	并发工具类 tools
* 	并发集合collections
![clipboard.png](https://img.hacpai.com/file/2019/11/clipboard-faf815ef.png)
### 并发工具类
*	闭锁 CountDownLatch
*	栅栏 CyclicBarrier
*	信号量 Semaphore
*	交换器 Exchanger

#### CountDownLatch:让主线程等待一组事件发生后继续执行
* 	事件是指CountDownLatch 里的 countDown()方法
![微信截图20191112231452.png](https://img.hacpai.com/file/2019/11/微信截图20191112231452-5781991c.png)
```
import java.util.concurrent.CountDownLatch;

public class CountDownLatchDemo {
    public static void main(String[] args) throws InterruptedException {
        new CountDownLatchDemo().go();
    }
    private void go() throws InterruptedException {
        CountDownLatch countDownLatch = new CountDownLatch(3);
        // 依次创建3个线程,并启动
        new Thread(new Task(countDownLatch), "Thread1").start();
        Thread.sleep(1000);
        new Thread(new Task(countDownLatch), "Thread2").start();
        Thread.sleep(1000);
        new Thread(new Task(countDownLatch), "Thread3").start();
        countDownLatch.await();
        System.out.println("所有线程已到达,主线程开始执行" + System.currentTimeMillis());
    }
    class Task implements Runnable {
        private CountDownLatch countDownLatch;
        public Task(CountDownLatch countDownLatch) {
            this.countDownLatch = countDownLatch;
        }
        @Override
        public void run() {
            System.out.println("线程" + Thread.currentThread().getName() + "已经到达" + System.currentTimeMillis());
            countDownLatch.countDown();
        }
    }
}
```
####	CyclicBarrier:阻塞当前线程，等待其他线程
*	等待其他线程，且会阻塞自己当前线程，所有的线程必须同时到达栅栏位置后，才能继续执行
*	所有线程到达栅栏处，可以触发执行另外一个预先设置的线程
![微信截图20191112232709.png](https://img.hacpai.com/file/2019/11/微信截图20191112232709-8f545850.png)
```
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierDemo {
    public static void main(String[] args) throws InterruptedException {
        new CyclicBarrierDemo().go();
    }
    private void go() throws InterruptedException {
        // 初始化栅栏的参与者数为3
        CyclicBarrier cyclicBarrier = new CyclicBarrier(4);
        // 依次创建3个线程,并启动
        new Thread(new Task(cyclicBarrier), "Thread1").start();
        Thread.sleep(1000);
        new Thread(new Task(cyclicBarrier), "Thread2").start();
        Thread.sleep(1000);
        new Thread(new Task(cyclicBarrier), "Thread3").start();
        Thread.sleep(1000);
        new Thread(new Task(cyclicBarrier), "Thread4").start();
    }
    class Task implements Runnable {
        private CyclicBarrier cyclicBarrier;
        public Task(CyclicBarrier cyclicBarrier) {
            this.cyclicBarrier = cyclicBarrier;
        }
        @Override
        public void run() {
            System.out.println("线程" + Thread.currentThread().getName() + "已经到达" + System.currentTimeMillis());
            try {
                cyclicBarrier.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
            System.out.println("线程" + Thread.currentThread().getName() + "开始处理" + System.currentTimeMillis());
        }
    }
}
```
####	Semaphore:控制某个资源可被同时访问的线程数
![微信截图20191112232929.png](https://img.hacpai.com/file/2019/11/微信截图20191112232929-a7070702.png)
```
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class SemaphoreDemo {
    public static void main(String[] args) {
        // 线程池
        ExecutorService exec = Executors.newCachedThreadPool();
        // 只能5个线程同时访问
        final Semaphore semp = new Semaphore(5);
        // 模拟20个客户端访问
        for (int index = 0; index < 20; index++) {
            final int NO = index;
            Runnable run = new Runnable() {
                public void run() {
                    try {
                        // 获取许可
                        semp.acquire();
                        System.out.println("Accessing: " + NO);
                        Thread.sleep((long) (Math.random() * 10000));
                        // 访问完后，释放
                        semp.release();
                    } catch (InterruptedException e) {
                    }
                }
            };
            exec.execute(run);
        }
        // 退出线程池
        exec.shutdown();
    }
}
```
未完待续...

