title: java.util.concurrent.Callable
date: '2019-11-14 10:34:54'
updated: '2019-11-14 10:34:54'
tags: [java, 多线程]
permalink: /articles/2019/11/14/1573698893916.html
---
### 1、Callable简介
**Callable**是类似于**Runnable**的接口，实现Callable接口的类和实现Runnable的类都 可被其它线程执行的任务。

###	2、Callable和Runnable有几点不同：
*	**Callable**规定的方法是**call()**，而**Runnable**规定的方法是**run()**.
*	**Callable**的任务执行后**可返回值**，而**Runnable**的任务是**不能返回值的**。
*	**call()** 方法可抛出异常，而**run()** 方法是不能抛出异常的。 
*	运行**Callable**任务可拿到一个**Future**对象，可了解任务执行情况，可取消任务的执行，还可获取任务执行的结果。

### 3、Demo演示
```
import java.util.concurrent.*;
import java.util.*;

class TaskWithResult implements Callable<String> {
  private int id;
  public TaskWithResult(int id) {
    this.id = id;
  }
  public String call() {
    return "result of TaskWithResult " + id;
  }
}

public class CallableDemo {
  public static void main(String[] args) {
    ExecutorService exec = Executors.newCachedThreadPool();
    ArrayList<Future<String>> results =
      new ArrayList<Future<String>>();
    for(int i = 0; i < 10; i++)
      results.add(exec.submit(new TaskWithResult(i)));
    for(Future<String> fs : results)
      try {
        // get() 方法会阻塞直到任务完成:
        System.out.println(fs.get());
      } catch(InterruptedException e) {
        System.out.println(e);
        return;
      } catch(ExecutionException e) {
        System.out.println(e);
      } finally {
        exec.shutdown();
      }
  }
  
} /* Output:
result of TaskWithResult 0
result of TaskWithResult 1
result of TaskWithResult 2
result of TaskWithResult 3
result of TaskWithResult 4
result of TaskWithResult 5
result of TaskWithResult 6
result of TaskWithResult 7
result of TaskWithResult 8
result of TaskWithResult 9
*///:~

```
