title: Java类加载器
date: '2019-11-08 09:38:45'
updated: '2019-11-08 09:38:45'
tags: [java, classloader]
permalink: /articles/2019/11/08/1573177125535.html
---
### 1）Bootstrap ClassLoader

>	负责加载$JAVA_HOME中jre/lib/rt.jar里所有的**class**，由C++实现，不是**ClassLoader**子类

### 2）Extension ClassLoader

 >  负责加载java平台中**扩展功能**的一些jar包，包括$JAVA_HOME中jre/lib/*.jar或-Djava.ext.dirs指定目录下的jar包

### 3）App ClassLoader

 >	负责记载**classpath**中指定的jar包及目录中 class

###	4）Custom ClassLoader

 >	属于应用程序根据自身需要**自定义**的ClassLoader，如tomcat、jboss都会根据**j2ee**规范自行实现ClassLoader


`加载过程中会先检查类是否被已加载，检查顺序是自底向上，从Custom ClassLoader到BootStrap ClassLoader逐层检查，只要某个classloader已加载就视为已加载此类，保证此类只所有ClassLoader加载一次。而加载的顺序是自顶向下，也就是由上层来逐层尝试加载此类。`
