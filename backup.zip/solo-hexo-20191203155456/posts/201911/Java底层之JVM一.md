title: Java底层之JVM(一)
date: '2019-11-22 10:21:07'
updated: '2019-11-22 11:13:14'
tags: [JVM]
permalink: /articles/2019/11/22/1574389267073.html
---
####	1、谈谈你对Java的理解

*	平台无关性：一次编译，导出运行

*	GC：垃圾回收机制,与C++相比，不用调用方法进行垃圾回收

*	语言特性：泛型、反射、lamda表达式

*	面向对象：封装 继承 多态

*	类库：java自带的集合，和并发库，网络库，IO NIO之类给的

*	异常处理 等
####	2、平台无关性如何实现

编译 javac Java源文件,生成com/interview/javabasic/bytecode/ByteCodeSample.class文件

``javac com/interview/javabasic/bytecode/ByteCodeSample.java``

运行 java java文件名成

``java com/interview/javabasic/bytecode/ByteCodeSample``

代码反汇编

``javad -c com/interview/javabasic/bytecode/ByteCodeSample.class``

![clipboard.png](https://img.hacpai.com/file/2019/11/clipboard-cdb61849.png)

Java源码首先被编译成字节码，再由不同的JVM进行解析，Java语言再不同平台上运行时不需要进行重新编译，

Java虚拟机在执行字节码的时候，把字节码转成具体平台的机器指令。

####	3、为什么JVM不直接将源码解析成机器码去执行
*	准备工作：每次执行都需要各种检查
*	兼容性：也可以将别的语言解析成字节码
####	4、什么是反射
>	Java反射机制是在**运行**状态**中**,
>	对于任意一个**类**，都能够**知道**这个类的的所有**属性和方法**;
>	对于任意一个**对象**,都能够**调用**它的任意**方法和属性**;
>	这种**动态获取信息**以及**动态调用对象**的功能称为Java语言的**反射机制**
```
public class Robot {
    private String name;
    public void sayHi(String helloSentence){
        System.out.println(helloSentence + " " + name);
    }
    private String throwHello(String tag){
        return "Hello " + tag;
    }
    static {
        System.out.println("Hello Robot");
    }
}

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectSample {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException, NoSuchFieldException {
        Class rc = Class.forName("Robot");
        Robot r = (Robot) rc.newInstance();
        System.out.println("Class name is " + rc.getName());
        Method getHello = rc.getDeclaredMethod("throwHello", String.class);
        getHello.setAccessible(true);
        Object str = getHello.invoke(r, "Bob");
        System.out.println("getHello result is " + str);
        Method sayHi = rc.getMethod("sayHi", String.class);
        sayHi.invoke(r, "Welcome");
        Field name = rc.getDeclaredField("name");
        name.setAccessible(true);
        name.set(r, "Alice");
        sayHi.invoke(r, "Welcome");
    }
}
/*Output:
Hello Robot
Class name is Robot
getHello result is Hello Bob
Welcome null
Welcome Alice
*/
```
####	5、谈谈ClassLoader
#####	1、类从编译到执行的过程
*	编译器将Robot.java源文件编译为Robot.class字节码文件
*	ClassLoader将字节码转换为JVM中的Class<Robot>对象
*	JVM利用Class<Robot>对象实例化Robot对象
#####	2、谈谈什么事ClassLoader
>ClassLoader在java中有着非常重要的作用，它主要工作在Class装载的加载阶段，它主要作用是从系统外外部获得Class二进制数据流。它是Java的核心组件，所有的Class都是由ClassLoader进行加载的，ClassLoader负责通过Class文件的二进制数据流装载进系统，让后交给Java虚拟机进行连接、初始化等操作。
#####	3、ClassLoader的种类
*	BootStrapClassLoader：C++ 编写，加载核心库java.*
*	ExtClassLoader:Java编写，加载扩展库javax.*
*	AppClassLoader:Java编写，加载程序所在目录
*	自动定义ClassLoader:Java编写，定制化加载
  
**自定义ClassLoader：MyClassLoader.java**
```
public class Wali{
	static{
		System.out.println("Hello Wali");
	}
}
public class ClassLoaderChecker {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        MyClassLoader m = new MyClassLoader("C:\\Users\\edhugo\\Desktop\\", "myClassLoader");
        Class c = m.loadClass("Wali");
        System.out.println(c.getClassLoader());
        System.out.println(c.getClassLoader().getParent());
        System.out.println(c.getClassLoader().getParent().getParent());
        System.out.println(c.getClassLoader().getParent().getParent().getParent());
        Object o = c.newInstance();
        System.out.println(o.getClass());
    }
}
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class MyClassLoader extends ClassLoader {
    private String path;
    private String classLoaderName;

    public MyClassLoader(String path, String classLoaderName) {
        this.path = path;
        this.classLoaderName = classLoaderName;
    }

    //用于寻找类文件
    @Override
    public Class findClass(String name) {
        byte[] b = loadClassData(name);
        return defineClass(name, b, 0, b.length);
    }

    //用于加载类文件
    private byte[] loadClassData(String name) {
        name = path + name + ".class";
        InputStream in = null;
        ByteArrayOutputStream out = null;
        try {
            in = new FileInputStream(new File(name));
            out = new ByteArrayOutputStream();
            int i = 0;
            while ((i = in.read()) != -1) {
                out.write(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return out.toByteArray();
    }
}
```
##### 5、ClassLoader的双亲委派机制
![微信截图20191122105352.png](https://img.hacpai.com/file/2019/11/微信截图20191122105352-6b59efa7.png)
*	自底向上检查类是否已经加载：
	Cutom ClassLoader -> App ClassLoder -> Extension ClassLoader -> Bootstap ClassLoader
*	自顶向下常释加载类
	Bootstap ClassLoader ->	Extension ClassLoader  -> App ClassLoder -> Cutom ClassLoader 
**底层实现**
[http://hg.openjdk.java.net/jdk8u/jdk8u/jdk/file/3ef3348195ff/src/share/native/java/lang/ClassLoader.c](http://hg.openjdk.java.net/jdk8u/jdk8u/jdk/file/3ef3348195ff/src/share/native/java/lang/ClassLoader.c)
![clipboard.png](https://img.hacpai.com/file/2019/11/clipboard-b0e94a5c.png)
##### 6、为什么要使用双亲委派机制去加载类
> 避免多分同样字节码的加载
##### 7、loadClass 和 Class.forName的区别
*	类的加载方式
1、	隐式加载: new
2、	显式加载：loadClass , forName 等
*	类的装载过程
1、	加载：通过ClassLoader加载class文件字节码，生成Class对象
2、	连接：
	2.1、校验：检查加载的class的正确性和安全性
	2.2、准备：为类变量分配存储空间并设置变量初始值
	2.3、解析：JVM将常量池内的符号引用转换为直接应用
3、执行类变量赋值和静态代码块

*	**loadClass 和 Class.forName的区别**
1、	Class.forName得到的class是已经初始化完成的
2、	ClassLoader.loadClass得到的class是还没有链接的
```
package com.interview.javabasic.reflect;
public class Robot {
    private String name;
    public void sayHi(String helloSentence){
        System.out.println(helloSentence + " " + name);
    }
    private String throwHello(String tag){
        return "Hello " + tag;
    }
    static {
        System.out.println("Hello Robot");
    }
}

public class LoadDifference {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
       ClassLoader cl = Robot.class.getClassLoader();
       System.out.println("---------------");
       Class r = Class.forName("com.interview.javabasic.reflect.Robot");
    }
}
/*OutPut:
--------------- 
Hello Robot
*/
```
