title: MySQL的limit使用及解决超大分页问题
date: '2019-11-22 09:32:38'
updated: '2019-11-22 09:32:38'
tags: [mysql]
permalink: /articles/2019/11/22/1574386358038.html
---
原文链接：https://juejin.im/post/5db658faf265da4d500f8386  
### 前言

日常开发中,我们使用mysql来实现分页功能的时候,总是会用到mysql的limit语法.而怎么使用却很有讲究的,今天来总结一下.

### limit语法

limit语法支持两个参数,**offset**和**limit**,前者表示偏移量,后者表示取前limit条数据.

例如:

```

## 返回符合条件的前10条语句 
select * from user limit 10

## 返回符合条件的第11-20条数据
select * from user limit 10,20
复制代码
```

从上面也可以看出来,`limit n` 等价于`limit 0,n`.

### 性能分析

实际使用中我们会发现,在分页的后面一些页,加载会变慢,也就是说:

`select * from user limit 1000000,10` 语句执行较慢.那么我们首先来测试一下.

首先是在offset较小的情况下拿100条数据.(数据总量为200左右).然后逐渐增大offset.

```
select * from user limit 0,100 ---------耗时0.03s
select * from user limit 10000,100 ---------耗时0.05s
select * from user limit 100000,100 ---------耗时0.13s
select * from user limit 500000,100 ---------耗时0.23s
select * from user limit 1000000,100 ---------耗时0.50s
select * from user limit 1800000,100 ---------耗时0.98s
复制代码
```

可以看到随着offset的增大,性能越来越差.

这是为什么呢?因为`limit 10000,10`的语法实际上是mysql查找到前10010条数据,之后丢弃前面的10000行,这个步骤其实是浪费掉的.

### 优化

#### 用id优化

先找到上次分页的最大ID,然后利用id上的索引来查询,类似于`select * from user where id>1000000 limit 100`.

这样的效率非常快,因为主键上是有索引的,但是这样有个缺点,就是ID必须是连续的,并且查询不能有where语句,因为where语句会造成过滤数据.

#### 用覆盖索引优化

mysql的查询完全命中索引的时候,称为覆盖索引,是非常快的,因为查询只需要在索引上进行查找,之后可以直接返回,而不用再回数据表拿数据.因此我们可以先查出索引的ID,然后根据Id拿数据.

```
select * from (select id from job limit 1000000,100) a left join job b on a.id = b.id;
复制代码
```

耗时0.2秒.

### 总结

用mysql做大量数据的分页确实是有难度,但是也有一些方法可以进行优化,需要结合业务场景多进行测试.

当用户翻到10000页的时候,不如我们直接返回空好了,这么无聊的吗...

  
完。  
  
 
