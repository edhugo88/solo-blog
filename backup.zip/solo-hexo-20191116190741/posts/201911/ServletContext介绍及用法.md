title: ServletContext介绍及用法
date: '2019-11-08 11:30:40'
updated: '2019-11-08 11:41:56'
tags: [Spring, Servlet]
permalink: /articles/2019/11/08/1573183839966.html
---
原文链接: https://blog.csdn.net/qq_36371449/article/details/80314024
## 1.1.  介绍
ServletContext官方叫servlet上下文。服务器会为每一个工程创建一个对象，这个对象就是ServletContext对象。这个对象全局唯一，而且工程内部的所有servlet都共享这个对象。所以叫全局应用程序共享对象。
![20180514193313700.png](https://img.hacpai.com/file/2019/11/20180514193313700-c63f62aa.png)


##	1.2.  作用
1.      是一个域对象

2.      可以读取全局配置参数

3.      可以搜索当前工程目录下面的资源文件

4.      可以获取当前工程名字（了解）

###	1.2.1.   servletContext是一个域对象
####	1.2.1.1.           域对象介绍
域对象是服务器在内存上创建的存储空间，用于在不同动态资源（servlet）之间传递与共享数据。

####	1.2.1.2.           域对象方法
凡是域对象都有如下3个方法：

setAttribute(name,value);name是String类型，value是Object类型；

往域对象里面添加数据，添加时以key-value形式添加

getAttribute(name);

根据指定的key读取域对象里面的数据

removeAttribute(name);

根据指定的key从域对象里面删除数据

####	1.2.1.3.           域对象功能代码
域对象存储数据AddDataServlet代码
```
	/**
	 * doGet
	 */
	publicvoid doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

         //往serlvetContext里面存数据

         //1.获取ServletContext对象

         //getServletContext()

         //2.往对象里面设置数据

         getServletContext().setAttribute("username", "admin");

         response.getOutputStream().write("用户名写入到servletContext成功".getBytes());

     }

 ```

获取域对象数据GetDataServlet代码
```
     /**
      * doGet
      */

     publicvoid doGet(HttpServletRequest request, HttpServletResponse response)

              throws ServletException, IOException {

         //获取ServletContext里面的用户名数据

         Object valueObject = getServletContext().getAttribute("username");

         if(valueObject!=null){

              response.getOutputStream().write(("从servletContext读取到的用户名数据："+valueObject.toString()).getBytes());

         }
     }
```
servletContext存储数据特点，

全局共享，里面的数据所有动态资源都可以写入和获取服务器启动的时候创建，服务器关闭的时候销毁，因为这是全局应用程序对象，全局共享对象。

###	 1.2.2.   可以读取全局配置参数
####	1.2.2.1.           servletContext读取全局参数核心方法
```
getServletContext().getInitParameter(name);//根据指定的参数名获取参数值 
getServletContext().getInitParameterNames();//获取所有参数名称列表

```

####	1.2.2.2.           实现步骤：
#####	1.      在web.xml中配置全局参数
```
  <!-- 全局配置参数，因为不属于任何一个servlet，但是所有的servlet都可以通过servletContext读取这个数据 -->

  <context-param>

         <param-name>param1</param-name>

         <param-value>value1</param-value>

  </context-param>

   <context-param>

         <param-name>param2</param-name>

         <param-value>value2</param-value>

  </context-param>
```

#####	2.      在动态资源servlet里面使用servletcontext读取全局参数代码
```
public void doGet(HttpServletRequest request, HttpServletResponse response)

                    throws ServletException, IOException {

           //使用servletContext读取全局配置参数数据

           //核心方法
           /*getServletContext().getInitParameter(name);//根据指定的参数名获取参数值
           getServletContext().getInitParameterNames();//获取所有参数名称列表*/


           //打印所有参数
           //1.先获取所有全局配置参数名称
           Enumeration<String> enumeration =  getServletContext().getInitParameterNames();

           //2.遍历迭代器
           while(enumeration.hasMoreElements()){

                    //获取每个元素的参数名字
                    String parameName = enumeration.nextElement();

                    //根据参数名字获取参数值
                    String parameValue = getServletContext().getInitParameter(parameName);

                    //打印
                    System.out.println(parameName+"="+parameValue);

           }

         }
```

###	1.2.3.   可以搜索当前工程目录下面的资源文件
####	1.2.3.1.           核心方法 getServletContext().getRealPath(path),根据相对路径获取服务器上资源的绝对路径

 getServletContext().getResourceAsStream(path),根据相对路径获取服务器上资源的输入字节流

###	1.2.4.   可以获取当前工程名字
####	1.2.4.1.           核心方法
```
getServletContext().getContextPath()；
```
 作用：获取当前工程名字

####	1.2.4.2.           代码
```
publicvoid doGet(HttpServletRequest request, HttpServletResponse response)

            throws ServletException, IOException {

        //获取工程名字,getServletContext().getContextPath()
        response.getOutputStream().write(("工程名字："+getServletContext().getContextPath()).getBytes());

    }

```


